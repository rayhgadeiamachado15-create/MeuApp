# Prebuilt and ready-for-use PRoot

Suffix `-pre5` is for variants compatible with Android versions before 5 (API < 21).

* `root/bin/proot` - regular.
* `root/bin/proot-userland` - with `USERLAND` macro defined.

See https://github.com/green-green-avk/proot and https://talloc.samba.org/talloc/doc/html/index.html for more info and licenses.
