//! Handler utilities for KDE shell protocols.

pub mod decoration;
mod handlers;
